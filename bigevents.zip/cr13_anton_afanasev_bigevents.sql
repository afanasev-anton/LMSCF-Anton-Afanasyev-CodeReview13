-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2020 at 02:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr13_anton_afanasev_bigevents`
--
CREATE DATABASE IF NOT EXISTS `cr13_anton_afanasev_bigevents` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cr13_anton_afanasev_bigevents`;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `descr` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `mail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `date`, `descr`, `img`, `capacity`, `mail`, `phone`, `city`, `zip`, `address`, `web`, `type`) VALUES
(2, 'Cats', '2021-01-15 18:00:00', 'Breathtaking dance, legendary costumes, a magical stage design, Grammy-awarded, electrifying music and the moving world hit \"Memory\", which has meanwhile been sung by more than 150 world-famous artists (including Barbra Streisand and Céline Dion), make CATS an unforgettable experience. A magical theatre evening for the whole family.', 'img/cats_1.jpg', 280, 'cats-musical@mail.com', '+431231234567', 'Vienna', 1020, 'Seilerstätte 9', 'www.musicalvienna.at', 'theater'),
(3, 'Jazz Jam', '2020-09-13 19:00:00', 'When the club was founded in 1972, there was only a small local jazz scene. Today, the realm of jazz, thanks to the pioneering work of Jazzland, which always brought together international stars with Austrian musicians, is well established in Vienna and thriving more than ever.', 'img/image_gallery.jfif', 50, 'office@jazzland.at', '+43 1 533 25 75', 'Vienna', 1010, 'Franz-Josefs-Kai 29', 'www.jazzland.at', 'music'),
(4, 'Porgy & Bess – The show must go on', '2020-04-13 20:30:00', 'Various representatives* of the local jazz scene were invited to small-scale information sessions (i.e. solo, duo, trio), which viewers can follow from home every Thursday and Saturday from 8.30 pm via www.porgy.at.', 'img/04172_4.jpg', 150, 'porgy@porgy.at', '+43 1 512 88 11', 'Vienna', 1010, 'Riemergasse 11', 'www.porgy.at', 'music'),
(5, 'Figaro', '2020-10-16 19:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'img/figaro.jpg', 300, 'opera@opera.at', '+439876543211', 'Vienna', 1010, 'Opera Ring 1', 'opera.at', 'opera'),
(6, 'UEFA Euro 2020', '2021-07-11 12:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'img/uefa.png', 70, 'uefa@uefa.com', '+51231569987', 'Rome', 135, 'Viale dei Gladiatori', 'uefa.com', 'sport');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
