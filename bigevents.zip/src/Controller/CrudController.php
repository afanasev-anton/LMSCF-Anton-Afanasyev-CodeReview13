<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
// connect with the database
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
// for the inputs
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Events;

class CrudController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function index()
    {
    	
    	$events = $this->getDoctrine()->getRepository('App:Events')->findAll();
        return $this->render('crud/index.html.twig', [
            'events' => $events,
            'musicActive'=>'dark',
            'sportActive'=>'dark',
            'theaterActive'=>'dark',
            'operaActive'=>'dark'
        ]);
    }
    /**
     * @Route("/{type}", name="home-type")
     */
    public function filterType($type)
    {
    	    	
    	$events = $this->getDoctrine()->getRepository('App:Events')->findBy(['type'=>$type]);
        return $this->render('crud/index.html.twig', [
            'events' => $events,            
            'musicActive'=>'dark',
            'sportActive'=>'dark',
            'theaterActive'=>'dark',
            'operaActive'=>'dark',
            $type.'Active'=>'danger'
        ]);
    }
    /**
    * @Route("/create", name="create_page")
    */
   	public  function createAction(Request $request)
   	{
      // Here we create an object from the class that we made
      $event = new Events;
      
      $form = $this->createFormBuilder($event)
       ->add('name', TextType::class, array('label'=> 'What?', 'attr' => array('class'=> 'form-control')))
       ->add('date', DateTimeType::class, array('label'=> 'When?', 'attr' => array('class'=> 'row no-gutters')))
       ->add('descr', TextareaType::class, array('label'=> 'Description', 'attr' => array('class'=> 'form-control')))
       ->add('img', TextType::class, array('label'=> 'Image link', 'attr' => array('class'=> 'form-control')))
       ->add('capacity', NumberType::class, array('label'=> 'Capacity', 'attr' => array('class'=> 'form-control')))
       ->add('mail', TextType::class, array('label'=> 'E-mail', 'attr' => array('class'=> 'form-control')))
       ->add('phone', TextType::class, array('label'=> 'Phone number', 'attr' => array('class'=> 'form-control')))
       ->add('city', TextType::class, array('label'=> 'City', 'attr' => array('class'=> 'form-control')))
       ->add('zip', NumberType::class, array('label'=> 'ZIP code','attr' => array('class'=> 'form-control')))
       ->add('address', TextType::class, array('label'=> 'Address (street and number)', 'attr' => array('class'=> 'form-control')))
       ->add('web', TextType::class, array('label'=> 'Web page (link)', 'attr' => array('class'=> 'form-control')))
       //“music”, “sport”, “movie”, “theater” etc.) 
       ->add('type', ChoiceType::class, array('label'=> 'Type of event', 'choices'=>array('Music'=>'music', 'Sport'=>'sport', 'Theater'=>'theater', 'Opera'=>'opera'),'attr' => array('class'=> 'form-control')))
       ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn btn-primary w-25 mt-2')))
       ->getForm();
      $form->handleRequest($request);

      /* Submit action and validation */
		if($form->isSubmitted() && $form->isValid()){
	        //fetching data
	        $name = $form['name']->getData();
	        $date = $form['date']->getData();
	        $descr = $form['descr']->getData();
	        $img = $form['img']->getData();
	        $capacity = $form['capacity']->getData();
	        $mail = $form['mail']->getData();
	        $phone = $form['phone']->getData();
	        $city = $form['city']->getData();
	        $zip = $form['zip']->getData();
	        $address = $form['address']->getData();
	        $web = $form['web']->getData();
	        $type = $form['type']->getData();

	        //set attributes for Event object
	        $event->setName($name);
	        $event->setDate($date);
	        $event->setDescr($descr);
	        $event->setImg($img);
	        $event->setCapacity($capacity);
	        $event->setMail($mail);
	        $event->setPhone($phone);
	        $event->setCity($city);
	        $event->setZip($zip);
	        $event->setAddress($address);
	        $event->setWeb($web);
	        $event->setType($type);

	        $em = $this->getDoctrine()->getManager();
	        $em->persist($event);
	        $em->flush();
	        $this->addFlash(
	        	'notice',
	        	'Event Added'
	        );
        	return $this->redirectToRoute('home');
    	}
    	return $this->render('crud/add.html.twig', array('form' => $form->createView()));
    }

    /**
    * @Route("/edit/{id}", name="edit_page")
    */
   	public  function editAction($id, Request $request)
   	{
   		$event = $this->getDoctrine()->getRepository('App:Events')->find($id);
   		
   		$event->setName($event->getName());
   		
   		$event->setDate($event->getDate());
	    $event->setDescr($event->getDescr());
	    $event->setImg($event->getImg());
	    $event->setCapacity($event->getCapacity());
	    $event->setMail($event->getMail());
	    $event->setPhone($event->getPhone());
	    $event->setCity($event->getCity());
	    $event->setZip($event->getZip());
	    $event->setAddress($event->getAddress());
	    $event->setWeb($event->getWeb());
	    $event->setType($event->getType());

	    //Edit form

	    $form = $this->createFormBuilder($event)
		->add('name', TextType::class, array('label'=> 'What?', 'attr' => array('class'=> 'form-control')))
		->add('date', DateTimeType::class, array('label'=> 'When?', 'attr' => array('class'=> 'row no-gutters')))
		->add('descr', TextareaType::class, array('label'=> 'Description', 'attr' => array('class'=> 'form-control')))
		->add('img', TextType::class, array('label'=> 'Image link', 'attr' => array('class'=> 'form-control')))
		->add('capacity', NumberType::class, array('label'=> 'Capacity', 'attr' => array('class'=> 'form-control')))
		->add('mail', TextType::class, array('label'=> 'E-mail', 'attr' => array('class'=> 'form-control')))
		->add('phone', TextType::class, array('label'=> 'Phone number', 'attr' => array('class'=> 'form-control')))
		->add('city', TextType::class, array('label'=> 'City', 'attr' => array('class'=> 'form-control')))
		->add('zip', NumberType::class, array('label'=> 'ZIP code','attr' => array('class'=> 'form-control')))
		->add('address', TextType::class, array('label'=> 'Address (street and number)', 'attr' => array('class'=> 'form-control')))
		->add('web', TextType::class, array('label'=> 'Web page (link)', 'attr' => array('class'=> 'form-control')))
       //“music”, “sport”, “movie”, “theater” etc.) 
		->add('type', ChoiceType::class, array('label'=> 'Type of event', 'choices'=>array('Music'=>'music', 'Sport'=>'sport', 'Theater'=>'theater', 'Opera'=>'opera'),'attr' => array('class'=> 'form-control')))
		->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn btn-primary w-25 mt-2')))
		->getForm();

		$form->handleRequest($request);

		if($form->isSubmitted() && $form->isValid()){
			//fetching data
	        $name = $form['name']->getData();
	        $date = $form['date']->getData();
	        $descr = $form['descr']->getData();
	        $img = $form['img']->getData();
	        $capacity = $form['capacity']->getData();
	        $mail = $form['mail']->getData();
	        $phone = $form['phone']->getData();
	        $city = $form['city']->getData();
	        $zip = $form['zip']->getData();
	        $address = $form['address']->getData();
	        $web = $form['web']->getData();
	        $type = $form['type']->getData();

	        //set attributes for Event object
	        $event->setName($name);
	        $event->setDate($date);
	        $event->setDescr($descr);
	        $event->setImg($img);
	        $event->setCapacity($capacity);
	        $event->setMail($mail);
	        $event->setPhone($phone);
	        $event->setCity($city);
	        $event->setZip($zip);
	        $event->setAddress($address);
	        $event->setWeb($web);
	        $event->setType($type);

	        $em = $this->getDoctrine()->getManager();
	        $em->persist($event);
	        $em->flush();
	        $this->addFlash(
	        	'notice',
	        	'Event updated'
	        );
        	return $this->redirectToRoute('home');
		}
		return $this->render('crud/edit.html.twig', array('form' => $form->createView()));
   	}

    /**
    * @Route("/details/{id}", name="details_page")
    */
   	public  function detailsAction($id)
   	{
   		$event = $this->getDoctrine()->getRepository('App:Events')->find($id);

   		return $this->render('crud/view.html.twig', ['event' => $event]);
   	}

    /**
    * @Route("/delete/{id}", name="car_delete")
    */
    public function deleteAction($id)
    {
    	$em = $this->getDoctrine()->getManager();
    	$event = $em->getRepository('App:Events')->find($id);
    	$em->remove($event);
    	$em->flush();
    	$this->addFlash(
    		'notice',
    		'Event removed'
    	);
    	return $this->redirectToRoute('home');
    }
}
